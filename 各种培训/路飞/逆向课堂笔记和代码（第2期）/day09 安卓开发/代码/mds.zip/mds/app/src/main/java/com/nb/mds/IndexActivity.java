package com.nb.mds;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

public class IndexActivity extends AppCompatActivity {
    private TextView txtToken;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_index);

        initView();

        initData();
    }

    private void initView() {
        txtToken = findViewById(R.id.txt_token);

    }
    private void initData(){
        // 读取xml文件中扥内容
        // 写到
        SharedPreferences sp = getSharedPreferences("sp_mds", MODE_PRIVATE);
        String token = sp.getString("token","");
        txtToken.setText(token);
    }
}