package com.nb.mds;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import java.io.IOException;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Map;

import okhttp3.Call;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;


public class MainActivity extends AppCompatActivity {
    public Context mContext;
    private Button btnReset, btnLogin;
    private TextView txtUser, txtPwd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // 打开界面时，此方法自动执行
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mContext = this;

        initView();
        initListener();
    }


    private void initView() {
        // 找到重置按钮:Button
        btnReset = findViewById(R.id.btn_reset);
        btnLogin = findViewById(R.id.btn_login);

        // 找到了两个输入框
        txtUser = findViewById(R.id.txt_user);
        txtPwd = findViewById(R.id.txt_pwd);

    }

    private void initListener() {

        // 给重置按钮绑定事件
        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetForm();
            }
        });

        // 给登录按钮绑定事件
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginForm();

            }
        });
    }

    /**
     * 重置表单
     */
    private void resetForm() {
        // 找到哪两个输入框
        // 将连个输入框清空
        txtUser.setText("");
        txtPwd.setText("");
    }

    /**
     * 用户登录
     */
    private void loginForm() {
        // 点击登录后执行的代码
        Log.e("APP开发-->", "登录了");

        // 1.获取用户名和密码
        /*
        String username = String.valueOf(txtUser.getText());
        String password = String.valueOf(txtUser.getText());
        */

        // 字符串拼接: "wupeiqi123"
        StringBuilder sb = new StringBuilder();

        // {"username":"wupeiqi","password":"123"}
        HashMap<String, String> dataMap = new HashMap<String, String>();

        // 用户输入的内容存在空
        boolean hasEmpty = false;

        // {username:对象， password:对象 }
        HashMap<String, TextView> txtMap = new HashMap<String, TextView>();
        txtMap.put("username", txtUser);
        txtMap.put("password", txtPwd);
        for (Map.Entry<String, TextView> entry : txtMap.entrySet()) {
            String key = entry.getKey();
            TextView txtObj = entry.getValue();
            String value = String.valueOf(txtObj.getText());
            if (value.trim().isEmpty()) {
                hasEmpty = true;
                break;
            }

            sb.append(value);
            dataMap.put(key, value);
        }

        // 用户输入的存在空
        if (hasEmpty) {
            Toast.makeText(this, "输入不能为空", Toast.LENGTH_SHORT).show();
            return;
        }

        // dataMap = {"username":"wupeiqi","password":"123"}
        // sb =  "wupeiqi123"
        String signString = md5(sb.toString());
        dataMap.put("sign", signString);

        // dataMap = {"username":"wupeiqi","password":"123","sign":"用户名和密码的md5值"}

        // 发送网络请求，三个动作
        // 1.引入，在build.gradle中 implementation "com.squareup.okhttp3:okhttp:4.9.1"
        // 2.配置，在AndroidManifest.xml中 <uses-permission android:name="android.permission.INTERNET"/>
        // 3.支持http（仅测试使用）

        // 发送POST请求 + 新创建线程

        new Thread() {
            @Override
            public void run() {
                OkHttpClient client = new OkHttpClient();
                FormBody form = new FormBody.Builder()
                        .add("user", dataMap.get("username"))
                        .add("pwd", dataMap.get("password"))
                        .add("sign", dataMap.get("sign")).build();

                Request req = new Request.Builder().url("http://192.168.0.6:9999/login").post(form).build();
                Call call = client.newCall(req);
                try {
                    Response res = call.execute();
                    ResponseBody body = res.body();
                    // 字符串={"status": true, "token": "fffk91234ksdujsdsd", "name": "武沛齐"}
                    String dataString = body.string();

                    // 对字符串进行反序列化，获取成对象。
                    HttpResponse context = new Gson().fromJson(dataString, HttpResponse.class);

                    // 将用户token和信息保存到特殊XML文件（写入）
                    SharedPreferences sp = getSharedPreferences("sp_mds", MODE_PRIVATE);
                    SharedPreferences.Editor editor = sp.edit();
                    editor.putString("token", context.token);
                    editor.commit();

                    // 跳转到其他页面 IndexActivity
                    Intent in = new Intent(mContext, IndexActivity.class);
                    startActivity(in);

                    // Log.e("MDS", "请求成功获取返回值=" + dataString);
                } catch (IOException ex) {
                    Log.e("MDS", "网络请求错误");
                }
            }
        }.start();


    }


    /**
     * md5加密
     *
     * @param dataString 待加密的字符串
     * @return 加密结果
     */
    private String md5(String dataString) {
        try {
            MessageDigest instance = MessageDigest.getInstance("MD5");
            byte[] nameBytes = instance.digest(dataString.getBytes());

            // 十六进制展示
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < nameBytes.length; i++) {
                int val = nameBytes[i] & 255;  // 负数转换为正数
                if (val < 16) {
                    sb.append("0");
                }
                sb.append(Integer.toHexString(val));
            }
            return sb.toString();
        } catch (Exception e) {
            return null;
        }

    }
}