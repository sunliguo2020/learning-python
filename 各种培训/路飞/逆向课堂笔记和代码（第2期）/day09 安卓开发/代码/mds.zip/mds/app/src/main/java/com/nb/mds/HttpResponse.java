package com.nb.mds;

class HttpResponse {
    public boolean status;
    public String token;
    public String name;
}