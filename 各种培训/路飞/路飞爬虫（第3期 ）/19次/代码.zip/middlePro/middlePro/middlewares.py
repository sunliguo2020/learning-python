# Define here the models for your spider middleware
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/spider-middleware.html

from scrapy import signals

# useful for handling different item types with a single interface
from itemadapter import is_item, ItemAdapter
from scrapy import Request

class MiddleproDownloaderMiddleware:
    #类方法：作用是返回一个下载器对象（忽略）
    @classmethod
    def from_crawler(cls, crawler):
        # This method is used by Scrapy to create your spiders.
        s = cls()
        crawler.signals.connect(s.spider_opened, signal=signals.spider_opened)
        return s
    #拦截处理所有的请求对象
    #参数：request就是拦截到的请求对象，spider爬虫文件中爬虫类实例化的对象
    #spider参数的作用可以实现爬虫类和中间类的数据交互
    def process_request(self, request, spider):
        request.headers['cookie'] = 'xxx'
        request.cookies = 'xxx'
        print(request.url+':请求对象拦截成功！')
        return None
    #拦截处理所有的响应对象
    #参数：response就是拦截到的响应对象，request就是被拦截到响应对象对应的唯一的一个请求对象
    def process_response(self, request, response, spider):
        print(request.url+':响应对象拦截成功！')
        return response
    #拦截和处理发生异常的请求对象
    #参数：reqeust就是拦截到的发生异常的请求对象
    #方法存在的意义：将发生异常的请求拦截到，然后对其进行修正
    def process_exception(self, request, exception, spider):
        print(request.url+':发生异常的请求对象被拦截到！')
        #修正操作
        #只有发生了异常的请求才使用代理机制，则可以写在该方法中
        request.meta['proxy'] = 'https://ip:port'
        return request #对请求对象进行重新发送
    #控制日志数据的（忽略）
    def spider_opened(self, spider):
        spider.logger.info('Spider opened: %s' % spider.name)
