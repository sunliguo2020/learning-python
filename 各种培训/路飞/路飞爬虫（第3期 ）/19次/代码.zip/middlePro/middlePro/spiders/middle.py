import scrapy


class MiddleSpider(scrapy.Spider):
    name = 'middle'
    # allowed_domains = ['www.xxx.com']
    start_urls = ['https://www123.baidu.com/','https://www.sogou.com/']
    proxy_list = []
    def parse(self, response):
        append(proxy_list)

