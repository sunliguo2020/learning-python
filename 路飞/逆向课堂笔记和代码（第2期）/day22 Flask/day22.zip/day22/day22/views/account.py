from flask import Blueprint, render_template, request, session,redirect

# 蓝图=中介
ac = Blueprint("account", __name__)


@ac.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        return render_template('login.html')
    user = request.form.get("user")
    pwd = request.form.get("pwd")

    # 根据用户名和密码去数据库做校验
    session["info"] = user

    # 登录成功，跳转到play页面
    # return render_template('login.html')
    return redirect('/play')


@ac.route("/logout")
def logout():
    return "退出"
