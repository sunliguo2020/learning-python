from flask import Blueprint, render_template, session, redirect

# 蓝图=中介
bi = Blueprint("bilibili", __name__)


@bi.route("/play")
def play():
    # 判断是否携带COOKIE & COOKIE值是否是正确（算法校验）
    data = session.get("info")
    if not data:
        return redirect('/login')

    return render_template("play.html")


@bi.route("/stop")
def stop():
    data = session.get("info")
    if not data:
        return redirect('/login')
    return "暂停"
