from flask import Flask, request, session, redirect

from .views.account import ac
from .views.bili import bi


def before():
    """ 函数没有返回值，则继续向后访问；有返回值，就拦截了。 """
    if request.path == "/login":
        return
    if request.path.startswith("/static"):
        return

    # 其他页面，就要判断，是否已登录
    data = session.get("info")
    if data:
        return
    return redirect('/login')


def create_app():
    app = Flask(__name__)
    app.secret_key = "asdfasdfupoajsdfaluidf;akjsdf;a09ufajksdf;kasdf"
    # 蓝图注册到app
    app.register_blueprint(ac)
    app.register_blueprint(bi)

    # 以后Flask的所有请求，都会先走before函数。
    app.before_request(before)

    return app
